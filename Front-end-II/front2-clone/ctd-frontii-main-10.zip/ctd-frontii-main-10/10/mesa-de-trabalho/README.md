# Aula 10 - Mesa de trabalho

A atividade consiste em devenvolver capturar e manipular os dados de uma formulário.
        
## Instruções

1. Selecione o formulário

2. Crie da rotina que será disparada a partir do evento de envio

    - 2.2. Remova todos os espaços vazios

    - 2.1. Remova todos os números permitindo apenas texto

3. Capture o evento de envio do formulário e disparar a rotina

    - 3.1. Apresentar o item no elemento DOM `<li class="c-lista__item">`.


<br><br>


**Nota:** Para entrega, siga o passo a passo do arquivo [__entregaDaAtividade__.md](https://gitlab.com/wssantanna/ctd-frontii/-/blob/main/10/mesa-de-trabalho/__entregaDaAtividade__.md).
