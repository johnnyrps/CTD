package Avaliacao_Parc_BeckEndI.Filiais;

public interface IDao<T>{

    public T salvar(T filial);


}
